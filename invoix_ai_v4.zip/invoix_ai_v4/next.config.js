module.exports={reactStrictMode:true};
